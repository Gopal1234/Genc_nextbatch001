import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html'
})
export class AdminComponent implements OnInit {
  adminMessage: string = '';

  constructor(private apiService: ApiService) {}

  ngOnInit() {
    this.apiService.getAdmin().subscribe(
      (data) => {this.adminMessage = data;

        console.log(data);
      },
      (error) => {this.adminMessage = 'Error fetching admin data';
    console.log(error);
      }

    );
  }
}
