export class User {
    userName: string = "";
  userPassword: string = "";
  roleNames: string[] = [];
    

}
