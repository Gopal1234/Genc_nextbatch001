import { Component } from '@angular/core';
import { User } from '../model/user';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  user:User = {
    userName: '',
    userPassword: '',
    roleNames: []
  };
 //ADMIN,USER
  roleNamesString: string = "";
  registrationMessage: string = '';
 
  constructor(private authService: AuthService){}

  registerUser() {
 
   
    console.log(this.user.userName+ " "+this.user.userPassword+ " "+this.user.roleNames);
      this.user.roleNames = this.roleNamesString.split(',').map(role => role.trim());
    
this.authService.register(this.user).subscribe(
      (response) => {
        this.registrationMessage = "Registraion Completed Successfully";
       console.log(this.registrationMessage);
      }
      ,
      (error) => {
        this.registrationMessage = "Registration Failed. Try again."
       
      }
    );
  }

  


}
