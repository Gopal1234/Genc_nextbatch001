import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:2040/auth';

  constructor(private http: HttpClient) {}

  login(credentials: { username: string; password: string }): Observable<string> {
    return this.http.post(`${this.apiUrl}/login`, credentials, { responseType: 'text' });
  }
  

  register(user: any): Observable<{message:string}> {
    return this.http.post<{message:string}>(`${this.apiUrl}/register`, user,{ responseType: 'text' as 'json' });
  }

  getUserRole(): string {
    const token = localStorage.getItem('jwtToken');
    console.log("Hello"+ token);
    if (token) {
      const payload = JSON.parse(atob(token.split('.')[1]));
      console.log(payload);
      return payload.roles;
    }
    return '';
  }
}
