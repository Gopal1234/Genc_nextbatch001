package com.org;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductWithImageApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductWithImageApplication.class, args);
	}

}
