package com.mail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.mail.MessagingException;

@RestController
@RequestMapping("/email")
public class EmailController {

    @Autowired
    private EmailService emailService;

    @PostMapping("/send")
    public String sendEmail(@RequestBody Email email) throws MessagingException {
        emailService.sendEmail(email.getTo(), email.getSubject(), email.getBody());
        return "Email sent successfully!";
    }
}
