package com.mail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMailDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringMailDemo1Application.class, args);
	}

}
