package com.org;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecutiryWithJwt1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecutiryWithJwt1Application.class, args);
	}

}
