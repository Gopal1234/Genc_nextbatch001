import { TestBed } from '@angular/core/testing';

import { ProuctService } from './prouct.service';

describe('ProuctService', () => {
  let service: ProuctService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProuctService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
