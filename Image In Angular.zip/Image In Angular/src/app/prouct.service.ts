import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from './product';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ProuctService {

  private apiUrl = 'http://localhost:1118/api/products';
  // URL base for images, as served by your backend
  private imageBaseUrl = 'http://localhost:1118/api/product-images/';

  constructor(private http: HttpClient) {}

  // Transform the original backend file path into the public URL.
  private transformUrl(url: string): string {
    // Extract the filename from the original path.
    const filename = url.split(/[\\/]/).pop();
    return `${this.imageBaseUrl}${filename}`;
  }

  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.apiUrl).pipe(
      map(products =>
        products.map(product => ({
          ...product,
          // Replace the original photoUrl with the backend-served image URL.
          photoUrl: this.transformUrl(product.photoUrl)
        }))
      )
    );
  }
}