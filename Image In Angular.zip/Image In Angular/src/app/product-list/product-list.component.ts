import { Component } from '@angular/core';
import { Product } from '../product';
import { ProuctService } from '../prouct.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {
  products: Product[] = [];

  constructor(private productService: ProuctService) {}

  ngOnInit() {
    this.productService.getProducts().subscribe(data => {
      this.products = data;
      console.log(this.products);
     // console.log('Transformed URL:', this.transformUrl('C:/Users/2404029/OneDrive - Cognizant/Pictures/img.png'));

    });
  }

}
