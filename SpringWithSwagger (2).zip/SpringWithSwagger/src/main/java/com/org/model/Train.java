package com.org.model;

public class Train {
	private int trainNumber;
	private String trainName;
	private double trainePrice;
	public int getTrainNumber() {
		return trainNumber;
	}
	public void setTrainNumber(int trainNumber) {
		this.trainNumber = trainNumber;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
	public double getTrainePrice() {
		return trainePrice;
	}
	public void setTrainePrice(double trainePrice) {
		this.trainePrice = trainePrice;
	}
	
	

}
