import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div>
      <h2>Lifecycle Demo</h2>
      <p>Counter from parent: {{ counter }}</p>
      <button (click)="toggle()">Toggle Child</button>
      <app-child *ngIf="showChild" [counter]="counter"></app-child>
      <button (click)="increment()">Increment</button>
    </div>
  `
})
export class AppComponent {
  /*title = 'welcome to cognizant!!!';
  isImportant = false;
  counter: number = 0;

  increment() {
    this.counter++;
  }

  decrement() {
    this.counter--;
  }
*/
counter = 0;
  showChild = true;

  increment() {
    this.counter++;
  }

  toggle() {
    this.showChild = !this.showChild;
  }
}
